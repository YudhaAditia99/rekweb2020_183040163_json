<?php

$mahasiswa =[
    "nama" => "Sandhika Galih",
     "nrp"  => "043040023",
     "email" => "sandhikagalih@unpas.ac.id"
];

$data = json_encode($mahasiswa);
echo $data;

?>